/* ═══════════════════════════════════════════════════════════════════
   AGROPECUÁRIA CATARINENSE — JS
   Particles · Counter · Tilt · Scroll Reveal · Map · Nav
═══════════════════════════════════════════════════════════════════ */

'use strict';

/* ─── UTIL ─────────────────────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const rnd = (a, b) => Math.random() * (b - a) + a;

/* ═══════════════════════════════════════════════════════════════════
   LOADER
═══════════════════════════════════════════════════════════════════ */
window.addEventListener('load', () => {
  setTimeout(() => {
    $('#loader').classList.add('hidden');
    document.body.style.overflow = 'visible';
    initReveal();
    triggerHeroReveals();
  }, 1900);
});
document.body.style.overflow = 'hidden';

/* ═══════════════════════════════════════════════════════════════════
   CURSOR
═══════════════════════════════════════════════════════════════════ */
(function initCursor() {
  const dot = $('.cursor-dot');
  const ring = $('.cursor-ring');
  if (!dot || !ring) return;
  if (window.matchMedia('(pointer:coarse)').matches) return;

  let mx = 0, my = 0, rx = 0, ry = 0;
  document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });

  const tick = () => {
    dot.style.left  = mx + 'px';
    dot.style.top   = my + 'px';
    rx = lerp(rx, mx, .12);
    ry = lerp(ry, my, .12);
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    requestAnimationFrame(tick);
  };
  tick();
})();

/* ═══════════════════════════════════════════════════════════════════
   NAVBAR
═══════════════════════════════════════════════════════════════════ */
(function initNav() {
  const nav = $('#navbar');
  const btn = $('#menuBtn');
  const mob = $('#mobileMenu');
  if (!nav) return;

  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });

  btn?.addEventListener('click', () => {
    btn.classList.toggle('open');
    mob.classList.toggle('open');
  });

  // close mobile on link click
  $$('.nav-mobile a').forEach(a => {
    a.addEventListener('click', () => {
      btn.classList.remove('open');
      mob.classList.remove('open');
    });
  });

  // active nav link on scroll
  const links = $$('.nav-link');
  const sections = links.map(l => $(l.getAttribute('href'))).filter(Boolean);

  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        links.forEach(l => l.classList.remove('active'));
        const link = links.find(l => l.getAttribute('href') === '#' + e.target.id);
        link?.classList.add('active');
      }
    });
  }, { threshold: .35 });

  sections.forEach(s => io.observe(s));
})();

/* ═══════════════════════════════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════════════════════════════ */
function initReveal() {
  const els = $$('.reveal-up, .reveal-left, .reveal-right');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const delay = parseInt(e.target.dataset.delay || 0);
        setTimeout(() => e.target.classList.add('visible'), delay);
        io.unobserve(e.target);
      }
    });
  }, { threshold: .1, rootMargin: '0px 0px -60px 0px' });

  els.forEach(el => io.observe(el));
}

function triggerHeroReveals() {
  $$('#hero .reveal-up').forEach(el => {
    const d = parseInt(el.dataset.delay || 0);
    setTimeout(() => el.classList.add('visible'), d + 200);
  });
}

/* ═══════════════════════════════════════════════════════════════════
   PARTICLE CANVAS
═══════════════════════════════════════════════════════════════════ */
(function initParticles() {
  const canvas = $('#particleCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let W, H, particles = [], mouse = { x: -9999, y: -9999 };

  const resize = () => {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  };
  resize();
  window.addEventListener('resize', resize, { passive: true });

  canvas.parentElement.addEventListener('mousemove', e => {
    const r = canvas.getBoundingClientRect();
    mouse.x = e.clientX - r.left;
    mouse.y = e.clientY - r.top;
  });

  class Particle {
    constructor() { this.reset(true); }
    reset(init) {
      this.x  = rnd(0, W);
      this.y  = init ? rnd(0, H) : H + 10;
      this.vy = rnd(-0.3, -1.0);
      this.vx = rnd(-0.2, 0.2);
      this.r  = rnd(1, 3.5);
      this.a  = rnd(0.2, 0.7);
      this.life = rnd(0.003, 0.006);
      this.fa   = this.a;
      // shape: 0=circle 1=cross/grain 2=diamond
      this.shape = Math.floor(rnd(0, 3));
      this.hue   = rnd(110, 160);
    }
    update() {
      // mouse repulsion
      const dx = this.x - mouse.x, dy = this.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 120) {
        const force = (120 - dist) / 120;
        this.vx += (dx / dist) * force * .4;
        this.vy += (dy / dist) * force * .4;
      }
      this.vx = clamp(this.vx, -1.5, 1.5);
      this.vy = clamp(this.vy, -1.8, 0.2);
      this.x += this.vx;
      this.y += this.vy;
      this.vx *= .98;
      this.fa -= this.life;
      if (this.fa <= 0 || this.y < -20) this.reset(false);
    }
    draw() {
      ctx.save();
      ctx.globalAlpha = Math.max(0, this.fa);
      ctx.strokeStyle = `hsl(${this.hue},80%,65%)`;
      ctx.fillStyle   = `hsl(${this.hue},80%,65%)`;

      if (this.shape === 0) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        ctx.fill();
      } else if (this.shape === 1) {
        // grain/seed shape
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(this.x, this.y - this.r * 2);
        ctx.lineTo(this.x, this.y + this.r * 2);
        ctx.moveTo(this.x - this.r, this.y);
        ctx.lineTo(this.x + this.r, this.y);
        ctx.stroke();
      } else {
        // diamond
        ctx.beginPath();
        ctx.moveTo(this.x, this.y - this.r * 1.5);
        ctx.lineTo(this.x + this.r, this.y);
        ctx.lineTo(this.x, this.y + this.r * 1.5);
        ctx.lineTo(this.x - this.r, this.y);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }
  }

  // init pool
  for (let i = 0; i < 120; i++) particles.push(new Particle());

  // connect nearby
  const connect = () => {
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const d  = Math.sqrt(dx * dx + dy * dy);
        if (d < 90) {
          ctx.save();
          ctx.globalAlpha = (1 - d / 90) * .12;
          ctx.strokeStyle = '#4ade80';
          ctx.lineWidth   = .5;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
          ctx.restore();
        }
      }
    }
  };

  const loop = () => {
    ctx.clearRect(0, 0, W, H);
    connect();
    particles.forEach(p => { p.update(); p.draw(); });
    requestAnimationFrame(loop);
  };
  loop();
})();

/* ═══════════════════════════════════════════════════════════════════
   COUNTER ANIMATION
═══════════════════════════════════════════════════════════════════ */
(function initCounters() {
  const els = $$('.stat-number');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseFloat(el.dataset.target);
      const prefix = el.dataset.prefix || '';
      const suffix = el.dataset.suffix || '';
      const isFloat = !Number.isInteger(target);
      const duration = 2000;
      const start = performance.now();

      const tick = (now) => {
        const progress = clamp((now - start) / duration, 0, 1);
        const ease = 1 - Math.pow(1 - progress, 3); // cubic ease-out
        const val = ease * target;
        el.textContent = prefix + (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
        if (progress < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      io.unobserve(el);
    });
  }, { threshold: .4 });

  els.forEach(el => io.observe(el));
})();

/* ═══════════════════════════════════════════════════════════════════
   PRODUCT BAR ANIMATION
═══════════════════════════════════════════════════════════════════ */
(function initBars() {
  const bars = $$('.pc-bar-fill');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.width = e.target.style.getPropertyValue('--pct') ||
          getComputedStyle(e.target).getPropertyValue('--pct');
        io.unobserve(e.target);
      }
    });
  }, { threshold: .3 });
  bars.forEach(b => io.observe(b));
})();

/* ═══════════════════════════════════════════════════════════════════
   TILT CARDS (3D hover)
═══════════════════════════════════════════════════════════════════ */
(function initTilt() {
  $$('.tilt-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const r = card.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top  + r.height / 2;
      const dx = (e.clientX - cx) / (r.width  / 2);
      const dy = (e.clientY - cy) / (r.height / 2);
      card.style.transform = `perspective(800px) rotateY(${dx * 6}deg) rotateX(${-dy * 6}deg) translateZ(4px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
})();

/* ═══════════════════════════════════════════════════════════════════
   MAP INTERACTION
═══════════════════════════════════════════════════════════════════ */
(function initMap() {
  const data = {
    oeste: {
      tag: 'Região Oeste',
      title: 'Oeste Catarinense',
      desc: 'O coração da proteína animal do Brasil. Chapecó, Concórdia e São Miguel do Oeste são referência mundial em suinocultura e avicultura. Grandes frigoríficos e cooperativas estruturam a economia regional.',
      products: ['🐷 Suinocultura', '🐔 Avicultura', '🥛 Leite', '🌽 Milho'],
      highlight: 'Chapecó é conhecida como a "Capital do Agronegócio" do Sul do Brasil.'
    },
    'meio-oeste': {
      tag: 'Região Meio-Oeste',
      title: 'Meio-Oeste Catarinense',
      desc: 'Zona de transição entre o litoral e o interior, com forte produção de aves, suínos e grãos. Videira e Caçador se destacam pela indústria frigorífica e pelo cultivo de uvas e maçãs.',
      products: ['🐔 Frango', '🍇 Uva', '🍎 Maçã', '🌾 Grãos'],
      highlight: 'Videira é o maior polo de processamento de frango do hemisfério sul.'
    },
    planalto: {
      tag: 'Planalto Serrano',
      title: 'Planalto Serrano',
      desc: 'O clima frio e as noites geladas criam condições ideais para a produção de maçã, pera e kiwi. Lages é o principal centro, combinando pecuária de corte e produção fruticultora de alta qualidade.',
      products: ['🍎 Maçã', '🐄 Gado de corte', '🌲 Reflorestamento', '🥛 Leite'],
      highlight: 'São Joaquim possui as maiores altitudes para cultivo de maçã do Brasil, garantindo sabor incomparável.'
    },
    vale: {
      tag: 'Vale do Itajaí',
      title: 'Vale do Itajaí',
      desc: 'Forte influência da colonização alemã e italiana. O Alto Vale concentra a produção de cebola, alho e pêssego. Destaque para a agricultura familiar de pequenas propriedades altamente produtivas.',
      products: ['🧅 Cebola', '🧄 Alho', '🍑 Pêssego', '🥦 Hortaliças'],
      highlight: 'Ituporanga é a "Capital Nacional da Cebola" — SC produz mais de 55% de toda a cebola brasileira.'
    },
    'litoral-norte': {
      tag: 'Litoral Norte',
      title: 'Litoral Norte',
      desc: 'Região com forte horticultura e produção de arroz em algumas planícies. A proximidade do mar favorece o cultivo de plantas tropicais e a produção de banana e mandioca.',
      products: ['🍌 Banana', '🥬 Hortaliças', '🌿 Mandioca', '🦞 Aquicultura'],
      highlight: 'A região é referência em aquicultura — criação de camarão, ostra e mexilhão.'
    },
    sul: {
      tag: 'Região Sul',
      title: 'Sul Catarinense',
      desc: 'Planícies extensas, ideais para a rizicultura irrigada de alta produtividade. Araranguá e Tubarão lideram a produção de arroz. O sul também tem forte tradição na produção de fumo/tabaco.',
      products: ['🌾 Arroz irrigado', '🚬 Fumo/Tabaco', '🐄 Pecuária', '🌽 Milho'],
      highlight: 'O arroz do sul de SC tem produtividade 40% acima da média nacional, graças ao solo e clima favoráveis.'
    },
    floripa: {
      tag: 'Grande Florianópolis',
      title: 'Grande Florianópolis',
      desc: 'Área periurbana com destaque para a ostreicultura — Santa Catarina é o maior produtor de ostras e mexilhões do Brasil. Municípios como Palhoça e Santo Amaro da Imperatriz têm produção hortifrutigranjeira relevante.',
      products: ['🦪 Ostras e mexilhões', '🥬 Horticultura', '🌹 Floricultura', '🍓 Frutas'],
      highlight: 'Florianópolis e região respondem por 90% das ostras produzidas no Brasil.'
    },
  };

  const regions = $$('.map-region');
  const detail  = $('#regionDetail');
  const placeholder = $('#regionPlaceholder');

  regions.forEach(r => {
    r.addEventListener('click', () => {
      const id = r.dataset.region;
      const d  = data[id];
      if (!d) return;

      regions.forEach(x => x.classList.remove('active'));
      r.classList.add('active');

      $('#rdTag').textContent = d.tag;
      $('#rdTitle').textContent = d.title;
      $('#rdDesc').textContent = d.desc;
      $('#rdProducts').innerHTML = d.products.map(p => `<span>${p}</span>`).join('');
      $('#rdHighlight').textContent = d.highlight;

      placeholder.style.display = 'none';
      detail.style.display = 'block';
      detail.style.animation = 'none';
      void detail.offsetWidth;
      detail.style.animation = '';
    });
  });
})();

/* ═══════════════════════════════════════════════════════════════════
   PARALLAX BACKGROUND TEXTS
═══════════════════════════════════════════════════════════════════ */
(function initParallax() {
  const bgTexts = $$('.hero-bg-text, .tech-bg-text');
  window.addEventListener('scroll', () => {
    const sy = window.scrollY;
    bgTexts.forEach(el => {
      const rate = el.classList.contains('hero-bg-text') ? .3 : -.15;
      el.style.transform = `translate(-50%, calc(-50% + ${sy * rate}px))`;
    });
  }, { passive: true });
})();

/* ═══════════════════════════════════════════════════════════════════
   SMOOTH ANCHOR SCROLL
═══════════════════════════════════════════════════════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

/* ═══════════════════════════════════════════════════════════════════
   GALLERY LIGHTBOX (simple)
═══════════════════════════════════════════════════════════════════ */
(function initLightbox() {
  const items = $$('.gallery-item');

  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position:fixed;inset:0;z-index:9000;
    background:rgba(0,0,0,.92);
    display:none;align-items:center;justify-content:center;
    backdrop-filter:blur(12px);
    cursor:zoom-out;
  `;
  const img = document.createElement('img');
  img.style.cssText = `
    max-width:90vw;max-height:88vh;
    border-radius:16px;
    box-shadow:0 0 80px rgba(0,0,0,.8);
    transition:transform .3s;
    object-fit:contain;
  `;
  const cap = document.createElement('p');
  cap.style.cssText = `
    position:absolute;bottom:2rem;left:50%;transform:translateX(-50%);
    color:rgba(255,255,255,.7);font-family:var(--font-body,sans-serif);
    font-size:.9rem;text-align:center;
  `;
  overlay.appendChild(img);
  overlay.appendChild(cap);
  document.body.appendChild(overlay);

  overlay.addEventListener('click', () => {
    overlay.style.display = 'none';
    document.body.style.overflow = '';
  });

  items.forEach(item => {
    item.style.cursor = 'zoom-in';
    item.addEventListener('click', () => {
      const src = item.querySelector('img')?.src;
      if (!src) return;
      const isPlaceholder = item.classList.contains('gi-no-img');
      if (isPlaceholder) return;
      img.src = src;
      cap.textContent = item.querySelector('.gi-overlay p')?.textContent || '';
      overlay.style.display = 'flex';
      document.body.style.overflow = 'hidden';
    });
  });
})();

/* ═══════════════════════════════════════════════════════════════════
   FLOATING GRAIN BACKGROUND (subtle)
═══════════════════════════════════════════════════════════════════ */
(function initGrain() {
  const canvas = document.createElement('canvas');
  canvas.style.cssText = `
    position:fixed;inset:0;z-index:1;
    pointer-events:none;opacity:.025;
    mix-blend-mode:overlay;
  `;
  canvas.width  = 256;
  canvas.height = 256;
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  const imageData = ctx.createImageData(256, 256);
  for (let i = 0; i < imageData.data.length; i += 4) {
    const v = Math.random() * 255 | 0;
    imageData.data[i] = imageData.data[i+1] = imageData.data[i+2] = v;
    imageData.data[i+3] = 255;
  }
  ctx.putImageData(imageData, 0, 0);
})();

/* ═══════════════════════════════════════════════════════════════════
   KEYBOARD ACCESSIBILITY
═══════════════════════════════════════════════════════════════════ */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    // close lightbox
    const overlay = document.querySelector('div[style*="z-index:9000"]');
    if (overlay) { overlay.style.display = 'none'; document.body.style.overflow = ''; }
  }
});
